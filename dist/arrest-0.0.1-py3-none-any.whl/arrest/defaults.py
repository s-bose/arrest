from arrest.http import ContentType

HEADER_DEFAULTS = {"Content-Type": ContentType.APPLICATION_JSON}
TIMEOUT_DEFAULT = 60  # sec
